﻿namespace WindowsFormsApplication2
{
    partial class econtact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.contactid = new System.Windows.Forms.Label();
            this.contactidtxtbox = new System.Windows.Forms.TextBox();
            this.contactnotxtbox = new System.Windows.Forms.TextBox();
            this.contactno = new System.Windows.Forms.Label();
            this.contactnametxtbox = new System.Windows.Forms.TextBox();
            this.contactname = new System.Windows.Forms.Label();
            this.addresstxtbox = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.gendertxtbox = new System.Windows.Forms.ComboBox();
            this.addbutton = new System.Windows.Forms.Button();
            this.updatebutton = new System.Windows.Forms.Button();
            this.deleatebutton = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Label();
            this.searchtxtbox = new System.Windows.Forms.TextBox();
            this.searchh = new System.Windows.Forms.Button();
            this.deleatelabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.updatetextbox = new System.Windows.Forms.TextBox();
            this.updatelable = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // contactid
            // 
            this.contactid.AutoSize = true;
            this.contactid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactid.Location = new System.Drawing.Point(895, 93);
            this.contactid.Name = "contactid";
            this.contactid.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.contactid.Size = new System.Drawing.Size(93, 24);
            this.contactid.TabIndex = 2;
            this.contactid.Text = "Contact Id";
            this.contactid.Click += new System.EventHandler(this.label1_Click);
            // 
            // contactidtxtbox
            // 
            this.contactidtxtbox.AccessibleName = "contacttext";
            this.contactidtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactidtxtbox.Location = new System.Drawing.Point(629, 89);
            this.contactidtxtbox.Name = "contactidtxtbox";
            this.contactidtxtbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.contactidtxtbox.Size = new System.Drawing.Size(230, 29);
            this.contactidtxtbox.TabIndex = 3;
            this.contactidtxtbox.Tag = "contactinfo";
            this.contactidtxtbox.TextChanged += new System.EventHandler(this.contactidtxtbox_TextChanged);
            // 
            // contactnotxtbox
            // 
            this.contactnotxtbox.AccessibleName = "contacttext";
            this.contactnotxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactnotxtbox.Location = new System.Drawing.Point(629, 144);
            this.contactnotxtbox.Name = "contactnotxtbox";
            this.contactnotxtbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.contactnotxtbox.Size = new System.Drawing.Size(230, 29);
            this.contactnotxtbox.TabIndex = 5;
            this.contactnotxtbox.Tag = "contactinfo";
            this.contactnotxtbox.TextChanged += new System.EventHandler(this.contactnotxtbox_TextChanged);
            // 
            // contactno
            // 
            this.contactno.AutoSize = true;
            this.contactno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactno.Location = new System.Drawing.Point(895, 144);
            this.contactno.Name = "contactno";
            this.contactno.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.contactno.Size = new System.Drawing.Size(119, 24);
            this.contactno.TabIndex = 4;
            this.contactno.Tag = "";
            this.contactno.Text = "Contact Num";
            // 
            // contactnametxtbox
            // 
            this.contactnametxtbox.AccessibleName = "contacttext";
            this.contactnametxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactnametxtbox.Location = new System.Drawing.Point(629, 195);
            this.contactnametxtbox.Name = "contactnametxtbox";
            this.contactnametxtbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.contactnametxtbox.Size = new System.Drawing.Size(230, 29);
            this.contactnametxtbox.TabIndex = 7;
            this.contactnametxtbox.Tag = "contactinfo";
            this.contactnametxtbox.TextChanged += new System.EventHandler(this.contactnametxtbox_TextChanged);
            // 
            // contactname
            // 
            this.contactname.AutoSize = true;
            this.contactname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactname.Location = new System.Drawing.Point(895, 200);
            this.contactname.Name = "contactname";
            this.contactname.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.contactname.Size = new System.Drawing.Size(129, 24);
            this.contactname.TabIndex = 6;
            this.contactname.Text = "Contact Name";
            this.contactname.Click += new System.EventHandler(this.label3_Click);
            // 
            // addresstxtbox
            // 
            this.addresstxtbox.AccessibleName = "contacttext";
            this.addresstxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstxtbox.Location = new System.Drawing.Point(629, 304);
            this.addresstxtbox.Multiline = true;
            this.addresstxtbox.Name = "addresstxtbox";
            this.addresstxtbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.addresstxtbox.Size = new System.Drawing.Size(230, 111);
            this.addresstxtbox.TabIndex = 9;
            this.addresstxtbox.Tag = "contactinfo";
            this.addresstxtbox.TextChanged += new System.EventHandler(this.addresstxtbox_TextChanged);
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.Location = new System.Drawing.Point(895, 304);
            this.address.Name = "address";
            this.address.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.address.Size = new System.Drawing.Size(69, 24);
            this.address.TabIndex = 8;
            this.address.Text = "Adress";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender.Location = new System.Drawing.Point(895, 252);
            this.gender.Name = "gender";
            this.gender.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gender.Size = new System.Drawing.Size(74, 24);
            this.gender.TabIndex = 10;
            this.gender.Text = "Gender";
            // 
            // gendertxtbox
            // 
            this.gendertxtbox.FormattingEnabled = true;
            this.gendertxtbox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.gendertxtbox.Location = new System.Drawing.Point(629, 250);
            this.gendertxtbox.Name = "gendertxtbox";
            this.gendertxtbox.Size = new System.Drawing.Size(230, 21);
            this.gendertxtbox.TabIndex = 12;
            this.gendertxtbox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // addbutton
            // 
            this.addbutton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.addbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbutton.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.addbutton.Location = new System.Drawing.Point(888, 444);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(97, 47);
            this.addbutton.TabIndex = 14;
            this.addbutton.Text = "Add";
            this.addbutton.UseVisualStyleBackColor = false;
            this.addbutton.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // updatebutton
            // 
            this.updatebutton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.updatebutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebutton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.updatebutton.Location = new System.Drawing.Point(764, 444);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(95, 47);
            this.updatebutton.TabIndex = 15;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = false;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click);
            // 
            // deleatebutton
            // 
            this.deleatebutton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.deleatebutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deleatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleatebutton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.deleatebutton.Location = new System.Drawing.Point(629, 444);
            this.deleatebutton.Name = "deleatebutton";
            this.deleatebutton.Size = new System.Drawing.Size(103, 47);
            this.deleatebutton.TabIndex = 16;
            this.deleatebutton.Text = "Delete";
            this.deleatebutton.UseVisualStyleBackColor = false;
            this.deleatebutton.Click += new System.EventHandler(this.deleatebutton_Click);
            // 
            // search
            // 
            this.search.AutoSize = true;
            this.search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.Location = new System.Drawing.Point(497, 91);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(66, 20);
            this.search.TabIndex = 18;
            this.search.Text = "Search";
            this.search.Click += new System.EventHandler(this.label6_Click);
            // 
            // searchtxtbox
            // 
            this.searchtxtbox.Location = new System.Drawing.Point(153, 93);
            this.searchtxtbox.Name = "searchtxtbox";
            this.searchtxtbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.searchtxtbox.Size = new System.Drawing.Size(339, 20);
            this.searchtxtbox.TabIndex = 19;
            this.searchtxtbox.TextChanged += new System.EventHandler(this.searchtxtbox_TextChanged);
            // 
            // searchh
            // 
            this.searchh.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.searchh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.searchh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchh.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.searchh.Location = new System.Drawing.Point(501, 444);
            this.searchh.Name = "searchh";
            this.searchh.Size = new System.Drawing.Size(103, 47);
            this.searchh.TabIndex = 20;
            this.searchh.Text = "Search";
            this.searchh.UseVisualStyleBackColor = false;
            this.searchh.Click += new System.EventHandler(this.searchh_Click);
            // 
            // deleatelabel
            // 
            this.deleatelabel.AutoSize = true;
            this.deleatelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleatelabel.Location = new System.Drawing.Point(497, 144);
            this.deleatelabel.Name = "deleatelabel";
            this.deleatelabel.Size = new System.Drawing.Size(62, 20);
            this.deleatelabel.TabIndex = 21;
            this.deleatelabel.Text = "Delete";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(153, 144);
            this.textBox1.Name = "textBox1";
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox1.Size = new System.Drawing.Size(339, 20);
            this.textBox1.TabIndex = 22;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // updatetextbox
            // 
            this.updatetextbox.Location = new System.Drawing.Point(153, 195);
            this.updatetextbox.Name = "updatetextbox";
            this.updatetextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.updatetextbox.Size = new System.Drawing.Size(339, 20);
            this.updatetextbox.TabIndex = 23;
            this.updatetextbox.TextChanged += new System.EventHandler(this.updatetextbox_TextChanged);
            // 
            // updatelable
            // 
            this.updatelable.AutoSize = true;
            this.updatelable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatelable.Location = new System.Drawing.Point(497, 195);
            this.updatelable.Name = "updatelable";
            this.updatelable.Size = new System.Drawing.Size(68, 20);
            this.updatelable.TabIndex = 24;
            this.updatelable.Text = "Update";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(153, 235);
            this.textBox2.Name = "textBox2";
            this.textBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox2.Size = new System.Drawing.Size(339, 20);
            this.textBox2.TabIndex = 25;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // econtact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(1274, 503);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.updatelable);
            this.Controls.Add(this.updatetextbox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.deleatelabel);
            this.Controls.Add(this.searchh);
            this.Controls.Add(this.searchtxtbox);
            this.Controls.Add(this.search);
            this.Controls.Add(this.deleatebutton);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.addbutton);
            this.Controls.Add(this.gendertxtbox);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.addresstxtbox);
            this.Controls.Add(this.address);
            this.Controls.Add(this.contactnametxtbox);
            this.Controls.Add(this.contactname);
            this.Controls.Add(this.contactnotxtbox);
            this.Controls.Add(this.contactno);
            this.Controls.Add(this.contactidtxtbox);
            this.Controls.Add(this.contactid);
            this.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "econtact";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "econtact";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label contactid;
        private System.Windows.Forms.TextBox contactidtxtbox;
        private System.Windows.Forms.TextBox contactnotxtbox;
        private System.Windows.Forms.Label contactno;
        private System.Windows.Forms.TextBox contactnametxtbox;
        private System.Windows.Forms.Label contactname;
        private System.Windows.Forms.TextBox addresstxtbox;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.ComboBox gendertxtbox;
        private System.Windows.Forms.Button addbutton;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Button deleatebutton;
        private System.Windows.Forms.Label search;
        private System.Windows.Forms.TextBox searchtxtbox;
        private System.Windows.Forms.Button searchh;
        private System.Windows.Forms.Label deleatelabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox updatetextbox;
        private System.Windows.Forms.Label updatelable;
        private System.Windows.Forms.TextBox textBox2;
    }
}

