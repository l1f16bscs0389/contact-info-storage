﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
//included libarayies 
using System.IO;
using System.Text;



namespace WindowsFormsApplication2
{
    public partial class econtact : Form
    {

        String loc = @"C:\Users\Daud Ahmad\Desktop\ooad project text file\WindowsFormsApplication2\bin\Debug\test.txt"; 
        
        string cid;
        string cno;
        string sex;
        string adres;
        string cname;
        string del;
        string update;
        string newdata; //used in updating
        string find;
        public econtact()
        {
            InitializeComponent();
        }
        
        private void label3_Click(object sender, EventArgs e)
        {
            //lablel3 is adress
        }

        private void label1_Click(object sender, EventArgs e)
        {
             //lablel1 is contact id
        }
        private void label2_Click(object sender, EventArgs e)
        {
            //lablel2 is contact #
        }
        private void label5_Click(object sender, EventArgs e)
        {
            //lablel2 is gender
        }


        /// <summary>
   
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
           private void Form1_Load(object sender, EventArgs e)
        {
 
        }

    /***********************************************
    * 
    * 
    *              UPDATE CLICK CODE              
    *              
    * *********************************************/
        private void updatebutton_Click(object sender, EventArgs e)
        {
            StreamReader reading = File.OpenText(loc);
            string str;
            while ((str = reading.ReadLine()) != null)
            {
                if (str.Contains(update))
                {
                    StreamWriter write = new StreamWriter(newdata);
                }
            }
            string text = File.ReadAllText(loc);
            text = text.Replace(update, newdata);
            File.WriteAllText(loc, text);

            updatetextbox.Text = null;
            textBox2.Text = null;
        }



        /***********************************************
         * 
         * 
         *              ADD CLICK CODE              
         *              
         * *********************************************/
        private void addbutton_Click(object sender, EventArgs e)
        {
            StreamWriter file = new StreamWriter(loc, true);
            StringBuilder sb = new StringBuilder("");
            if (contactnotxtbox.Text != null && contactidtxtbox.Text != null && gendertxtbox.Text != null && contactnametxtbox.Text != null && addresstxtbox.Text != null)
            {
                sb.AppendLine(cid + "     " + cname + "   " + cno + "     " + sex + "     " + adres);
                file.WriteLine(sb);

            }
            else
            {
                MessageBox.Show("Enter all the fields to continue.");
                contactnotxtbox.Text = null;
                contactidtxtbox.Text = null;
                gendertxtbox.Text = null;
                contactnametxtbox.Text = null;
                addresstxtbox.Text = null;
                return;
            }

            file.Close();
            //to remove the previous input data on the main page
            contactnotxtbox.Text = null;
            contactidtxtbox.Text = null;
            gendertxtbox.Text = null;
            contactnametxtbox.Text = null;
            addresstxtbox.Text = null;

         
        }

        /***********************************************
       * 
       * 
       *              DELETE CLICK CODE              
       *              
       * *********************************************/
        private void deleatebutton_Click(object sender, EventArgs e)
        {
            /*
            int check = 0;
            int counter = 0;
            string line;
            string temp = del;
            string groin;
            //   Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(loc);
            while ((line = file.ReadLine()) != null)
            {
                if (line == "")
                    continue;
                groin = line.Substring(0, line.IndexOf(" "));
                if (groin == temp)
                {
                    check++;
                    break;
                }
                counter++;

            }

            if (check > 0)
            {

                MessageBox.Show("found." + line);
            }
            else
            {
                MessageBox.Show("Not found.");

            }
            file.Close();
           */

            //  net code 
            //            System.IO.StreamReader file =
            //                new System.IO.StreamReader(loc);
            //            string line = file.ReadLine();
            //            File.WriteAllLines("myfile.txt"
            //, File.ReadLines(loc).Where( s => s != del).ToList()
            //);

//        net  code
            //StringBuilder sb = new StringBuilder();
            //using (StreamReader sr = new StreamReader(loc))
            //{
            //    int Countup = 0;
            //    while (!sr.EndOfStream)
            //    {
            //        Countup++;
            //        if (Countup != Line)
            //        {
            //            using (StringWriter sw = new StringWriter(sb))
            //            {
            //                sw.WriteLine(sr.ReadLine());
            //            }
            //        }
            //        else
            //        {
            //            sr.ReadLine();
            //        }
            //    }
            //}
            //using (StreamWriter sw = new StreamWriter(loc))
            //{
            //    sw.Write(sb.ToString());



            //////////////////}

        }

        /***********************************************
       * 
       * 
       *              SEARCH CLICK CODE              
       *              
       * *********************************************/
        private void searchh_Click(object sender, EventArgs e)
        {
             int check=0;
             int counter = 0;
             string line;
            string temp=find;
            string groin;
           //   Read the file and display it line by line.  
             System.IO.StreamReader file =
                 new System.IO.StreamReader(loc);
             while ((line = file.ReadLine()) != null)
             {
                 if (line == "")
                     continue;
                 groin = line.Substring(0,line.IndexOf(" "));
                 if(groin==temp)
                 {
                     check++;
                     break;
                 }
                 counter++;
               
             }
             
             if (check > 0)
             { 
                 MessageBox.Show("found. " +line);
             }
             else
             {
                 MessageBox.Show("Not found.");
                 
             }
             file.Close();
            searchtxtbox.Text = null;
}

        private void label6_Click(object sender, EventArgs e)
        {
            //search
             
        }
               /***********************************************
               * 
               * 
               *            CODING FOR THE DISPLAYED TEXT BOXES              
               *              
               * *********************************************/
        private void contactidtxtbox_TextChanged(object sender, EventArgs e)
        {
            cid = Convert.ToString(contactidtxtbox.Text);
            
        }
//--------------------------------------------------------------------------------------------------->
        private void contactnotxtbox_TextChanged(object sender, EventArgs e)
        {
            cno = Convert.ToString(contactnotxtbox.Text);
        }
//--------------------------------------------------------------------------------------------------->
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            sex = Convert.ToString(gendertxtbox.Text);//option betw male female
        }
//--------------------------------------------------------------------------------------------------->
        private void addresstxtbox_TextChanged(object sender, EventArgs e)
        {
            adres = Convert.ToString(addresstxtbox.Text);
        }
//--------------------------------------------------------------------------------------------------->
        private void contactnametxtbox_TextChanged(object sender, EventArgs e)
        {
            cname = Convert.ToString(contactnametxtbox.Text);
        }
//--------------------------------------------------------------------------------------------------->      
        private void searchtxtbox_TextChanged(object sender, EventArgs e)
        {
            find = Convert.ToString(searchtxtbox.Text);
        }

//--------------------------------------------------------------------------------------------------->
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            del = Convert.ToString(textBox1.Text);
        }
//--------------------------------------------------------------------------------------------------->
        private void updatetextbox_TextChanged(object sender, EventArgs e)
        {
            update = Convert.ToString(updatetextbox.Text);
        }

        /***********************************************
        * 
        *       A NEW TXTBOX TO GET THE NEW VALUE WHICH UILL BE UPDATED              
        *              
        * *********************************************/
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            newdata = Convert.ToString(textBox2.Text);
        }
//--------------------------------------------------------------------------------------------------->
    }
}

