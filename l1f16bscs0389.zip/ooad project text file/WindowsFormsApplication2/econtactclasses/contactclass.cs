﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2.econtactclasses
{
    class contactclass
    {
        //getter setters 
        //data carrior of app
        public int contactid { get; set; }
        public string contactname { get; set; }
        public string contactnumber { get; set; }
        public string address { get; set; }
        public string gender { get; set; }


       

        }
    }


